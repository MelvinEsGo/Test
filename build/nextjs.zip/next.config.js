const withCloud = require("@serverless/cloud/nextjs");

module.exports = withCloud({
  reactStrictMode: true,
});
